// Edited by Karan Katyal and Aniket Panhale
package com.aerotravel.flightticketbooking.services;

import org.springframework.security.core.userdetails.UserDetailsService;

public interface UserService extends UserDetailsService {
}
